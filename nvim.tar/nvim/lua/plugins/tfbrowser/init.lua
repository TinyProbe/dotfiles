require("telescope").load_extension("file_browser")
displayKeymap("n", {silent=true, desc="n:TFBrowser"}, "<leader>fb", "<cmd>Telescope file_browser<CR>")
