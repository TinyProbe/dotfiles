-- activate all
require("colorizer").setup(nil, { css = true; })
