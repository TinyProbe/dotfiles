vim.cmd([[
inoreabbrev $<html_base>
\ <!DOCTYPE html>
\<NL><html>
\<NL><head>
\<NL><meta charset="utf-8">
\<NL><title>Hello World!</title>
\<NL></head>
\<NL><body>
\<NL><h1>Hello World!</h1>
\<NL></body>
\<NL></html>
]])
